# pragma once
# include <cassert>
# include <iostream>



class Matrix {
    private:
        int rows;
        int colums;
        double **index;

    public:
        // konstruktør for matrise n*m med 0 i alle felt
        Matrix (int n_rows, int m_colums);   


        // eksplisitt n*n matrise med null i alle felt
        explicit Matrix (int n_rows);

        // destruktør
        ~Matrix ();

        // kopikonstruktør
        Matrix (const Matrix &other);

        double get (int row, int col) const;
        void set (int row, int col, double value);
        int get_size_rows () const;
        int get_size_colums () const;

        // usikker på denne
        double *&operator[] (int row);
        Matrix &operator= (Matrix rhs);
        Matrix &operator+= (Matrix rhs);
        Matrix &operator+ (Matrix rhs);
        Matrix &operator-= (Matrix rhs);
        Matrix &operator- (Matrix rhs);
        Matrix &operator*= (Matrix rhs);
        Matrix &operator* (Matrix rhs);
        
    friend std::ostream &operator<< (std::ostream &os, Matrix &A);
};

std::ostream &operator<< (std::ostream &os, const Matrix &A);



