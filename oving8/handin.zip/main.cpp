# include "oppgave_1.h"
# include "oppgave_2.h"
# include "oppgave_3.h"

int main () {
    // oppgave 1;
    //create_fibonacci ();


    Matrix A (3, 2);
    std::cout << A << std::endl;

    
    dummy_test ();
    return 0;
}

/* oppgave 3a
Når dummy kjøres vil det skrives ut:
a: 4
b: 4
c: 4
a: 4
b: 3
c: 5

3b)
Jeg er usikker på hvorfor oppgaven returnerer det den gjør. Jeg er også usikker på hvorfor programmet krasjer.
4
4
4
5
5
5

*/
