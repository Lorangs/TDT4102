# include "oppgave_1.h"

void fill_in_fibonacci_numbers (int *result, int length) {
    int next_number = 1;
    int last_number = 0;
    for (int i = 0; i < length; i++) {
        result[i] = last_number;
        next_number = next_number + last_number;
        last_number = next_number - last_number; 
    }
}

void print_array (int *arr, int length) {
    for (int i = 0; i < length; i++) {
        std::cout << i << '\t' << arr[i] << std::endl;
    }
}

void create_fibonacci () {
    int length;
    std::cout << "Hvor lang er tallrekka?" << '\t';
    std::cin >> length;

    int *result = new int[length];
    
    fill_in_fibonacci_numbers (result, length);
    print_array (result, length);
    delete [] result;
}