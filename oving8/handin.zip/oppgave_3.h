# pragma once
# include <iostream>
# include <utility>

class Dummy {
    public:
        int *num;
        Dummy () {
            num = new int {0};
        };
        ~Dummy () {
            delete num;
        };
        // kopikonstruktør
        Dummy (const Dummy &other) : num {nullptr} {
            this -> num = new int {};
            num = other.num;
        };
        Dummy &operator= (Dummy rhs);
};

void dummy_test ();