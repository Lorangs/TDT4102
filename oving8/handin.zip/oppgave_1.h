# pragma once
# include <iostream>

void fill_in_fibonacci_numbers (int *result, int length);
void print_array (int *arr, int length);
void create_fibonacci ();