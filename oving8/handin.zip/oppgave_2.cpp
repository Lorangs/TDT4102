# include "oppgave_2.h"

Matrix::Matrix (int n_rows, int m_colums) : 
            rows {n_rows}, 
            colums {m_colums}
        {
            assert (n_rows >= 0 && m_colums >= 0);

            // Litt usikker på det puktet her:  
            double **index = new double*[n_rows];
            for (int i = 0; i < n_rows; i++) {
                index[i] = new double [m_colums] {0.0};         
            }  
        };   

Matrix::Matrix (int n_rows) : Matrix {n_rows, n_rows} {}

Matrix::~Matrix () {
    for (int i = 0; i < rows; i++) {
        delete[] index[i];
    }
    delete[] index;
};

Matrix::Matrix (const Matrix &other) : index {nullptr} {
    this -> index = new double *[other.rows];
    for (int i = 0; i < other.rows; i++) {
        for (int j = 0; j < other.colums; j++) {
            index[i][j] = other.get (i, j);
        }       
    }  
}

double Matrix::get (int row, int col) const { 
    return index[row][col];
}

void Matrix::set (int row, int col, double value) {
    index[row][col] = value;
}

int Matrix::get_size_rows () const {
    return rows;
}

int Matrix::get_size_colums () const {
    return colums;
}

// veldig usikker på denne
double *&Matrix::operator[] (int row) {
    if (row >= rows) {
        std::cout << "Index out of bound." << std::endl;
        exit (0);
    }
    return index[row];
}

Matrix &Matrix::operator= (Matrix rhs) {
    std::swap (rows, rhs.rows);
    std::swap (colums, rhs.colums);
    std::swap (index, rhs.index);
    return *this;
}

Matrix &Matrix::operator+= (Matrix rhs) {
    assert (rows == rhs.rows && colums == rhs.colums); 
    for (int i = 0; i < rows; i++){
        for (int j = 0; j < colums; j++) {
            index[i][j] += rhs.index [i][j];
        }
    }
    return *this;
}

Matrix &Matrix::operator+ (Matrix rhs) {
    assert (rows == rhs.rows && colums == rhs.colums);
    Matrix kopi (*this);
    return kopi += rhs;
}

Matrix &Matrix::operator-= (Matrix rhs) {
    assert (rows == rhs.rows && colums == rhs.colums);
    for (int i = 0; i < rows; i++){
        for (int j = 0; j < colums; j++) {
            index[i][j] -= rhs.index [i][j];
        }
    }
    return *this;
}

Matrix &Matrix::operator- (Matrix rhs) {
    assert (rows == rhs.rows && colums == rhs.colums);
    Matrix kopi (*this);
    return kopi -= rhs;
}


// denne byr på problemer med minneallokering fordi matrisen 
// blir større etter matrisemultiplikasjon.
Matrix &Matrix::operator*= (Matrix rhs) {
    assert (colums == rhs.rows);
    
    for (int m = 0; m < rows; m++){
        for (int  n= 0; n < colums; n++) { 
            double sum;
            for (int p = 0; p < rhs.colums; p++) {
                sum = index[m][n] * rhs.index [n][p];
            }
            index[m][n] = sum;            
        }
    }
    return *this;
}

Matrix &Matrix::operator* (Matrix rhs) {
    assert (colums == rhs.rows);
    Matrix kopi (*this);
    return kopi *= rhs;
}

std::ostream &operator<< (std::ostream &os, Matrix &A) {
    for (int i = 0; i < A.rows; i++) {
        for (int j = 0; j < A.colums; j++) {
            os << A.index[i][j] << '\t';
        }
        os << '\n';
    }
    return os;
}