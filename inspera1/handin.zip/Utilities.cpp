#include "Utilities.h"
# include <string>
# include <random>

string toGreek(string sentence)
{
    // BEGIN: 2a
    std::string new_sentence;
    for (char ch : sentence) {
        if (isalpha (ch)) {
            new_sentence += ch + 2;
        }
        else {
            new_sentence += ch;
        }
    }
    return new_sentence;    
    // END: 2a
}

vector<vector<string>> loadSvada()
{
    // BEGIN: 2b

    std::filesystem::path filepath {"SvadaWords.txt"};
    std::ifstream input_stream {filepath};

    std::vector<std::vector<std::string>> svadaVec;
    std::string section;
    std::string word;

    while (getline (input_stream, section, "||")) {

        std::vector<string> sect;
        while (getline (section, word, "\n")) {
            sect.push_back (word);
        }

        svadaVec.push_back (sect);        
    }
    return svadaVec;

    // END: 2b
}

string svadaGenerator(vector<vector<string>> svadaVec)
{
    // BEGIN: 2c1
    string svada_sentence;

    for (std::vector<std::string> section : svadaVec) {
        std::string word = section.at (randomWithLimits (0, 23));
        svada_sentence += word;
    }
    return svada_sentence;
}

int randomWithLimits (int lower, int upper) {
    std::uniform_int_distribution<int> distribution (lower, upper);
    std::random_device random;
    std:: default_random_engine generator (random ());

    return distribution (generator);
}
    // END: 2c1