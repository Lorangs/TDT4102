#include "ContractDataBase.h"

InsuranceContract ContractDataBase::getContract(int id)
{
// BEGIN: 1b
    for (int i = 0; i < contracts.size (); i++) {
        if (id == contracts.at (i).getId ()) {
            return contracts.at (i);
        }
    }
// END: 1b

    // Returning an empty contract if no contract with the given id is found.
    return InsuranceContract{};
}

int ContractDataBase::numberOfInsuranceType(InsuranceType type)
{
    // BEGIN: 1c
    std::vector<InsuranceType> num_types;
    for (InsuranceContract c : contracts) {
        for (InsuranceType nt : num_types){
            if (std::count (num_types.begin (), num_types.end (), c.getInsuranceType ())) {}
            else {
                num_types.push_back (c.getInsuranceType ());
            }   
        }
    }
    return num_types.size();
    // END: 1c
}

int ContractDataBase::addContract(string holderName, InsuranceType insType, int value)
{
    // BEGIN: 1d 
    if (contracts.size () == 0) {
        contracts.push_back (InsuranceContract (holderName, insType, value, 1, "Text missing!"));
        return 1;
    }
    
    else {
        int max_id = 0;
        for (int i = 0; i < contracts.size (); i++) {
            if (contracts.at (i).getId () > max_id) {
                max_id = contracts.at (i).getId ();
            }
        contracts.push_back (InsuranceContract (holderName, insType, value, max_id + 1, "Text missing!"));
        return max_id + 1;
        }
    }
    // END: 1d
}

void ContractDataBase::saveContracts(string filename)
{
    // BEGIN: 1e

    std::filesystem::path file {filename};
    std::ofstream output_stream {file};

    for (InsuranceContract I : contracts) {
        output_stream 
        << I.getHolder () << ","
        << insuranceTypeToString (I.getInsuranceType ()) << ","
        << I.getValue () << ","
        << I.getId () << ","
        << I.getInsuranceText () << "," << std::endl;
    }
    // END: 1e
}

void ContractDataBase::loadContracts(string filename)
{
    ifstream inFile{filename};
    if (!inFile)
    {
        error("Couldn't open file: ", filename);
    }

    string line;
    while (getline(inFile, line))
    {
        stringstream ss{line};
        char seperator;

        string holderName;
        getline(ss, holderName, ',');

        string insType;
        getline(ss, insType, ',');

        int value;
        ss >> value;
        ss >> seperator;

        int id;
        ss >> id;
        ss >> seperator;

        string insuranceText;
        getline(ss, insuranceText, ',');

        contracts.push_back({holderName, stringToInsuranceType.at(insType), value, id, insuranceText});
    }
}
