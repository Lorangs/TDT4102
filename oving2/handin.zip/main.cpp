# include "std_lib_facilities.h"
# include "AnimationWindow.h"
# include "iostream"
# include <vector>

int add (int a, int b) {
    cout << a << " + " << b << " = " << a + b << endl;
    return a + b;
}

void inputIntegersAndPrintProduct () {
    int x = 0;
    int y = 0;

    cout << "Skriv inn to heltall: ";
    cin >> x;
    cin >> y;

    int product = x * y;
    cout << x << " * " << y << " = " << product << endl;
}

// Oppgave 1b)
void inputAndPrintInteger() {
    int n;
    cout << "Skriv inn et tall: ";
    cin >> n;
    cout << "Du skrev: " << n << endl;
}

// Oppgave 1c)
int inputInteger() {
    int n;
    cout << "Skriv inn et tall: ";
    cin >> n;
    return n;
}

// Oppgave 1d)
void inputIntegersAndPRintSum () {
    int summen = 0;
    for (int i = 0; i < 2; i++) {
        summen += inputInteger();
    }
    cout << "Summen er: " << summen << endl;
}

// Oppgave 1e)
    // Jeg valgte å bruke funksjonen InputInteger()
    // fordi denne funksjonen returnerer heltallet n, ikke bare printer det.

// Oppgave 1f)
bool isOdd(int a) {
    if (a % 2 == 1) {
        return true;
    }
    else {
        return false;
    }
}

// Oppgave 1g)
void printHumanReadableTime (int sek) {
    int timer = sek / 3600;
    int minutt = (sek % 3600) / 60;
    int sekund = sek % 60;

    cout << timer << " timer " << minutt << " minutter " << sekund << " sekunder" << endl;
}

// Oppgave 2a)
int addDefinedNumbers () {
    int question;
    cin >> question;
    int summen = 0;

    for (int i = 0; i < abs(question); i++) {
        cout << "skriv inn et tall du vil legge til: ";
        cin >> question;
        summen += question;
    }
    cout << "Summen er: " << summen << endl;
    return summen;
}

// Oppgave 2b)
int addSeveralNumbers () {
    int summen = 0;
    int question;

    while (question != 0) {
        cout << "skriv inn et tall du vil legge til: ";
        cin >> question;
        summen += question;
    }
    cout << "Summen er: " << summen << endl;
    
    return summen;
}

// Oppgave 2c)
    // I oppgave 2a skal det brukes et definert antall tall som skal summeres. En FOR-løkke er passende.
    // I oppgave 2b er det et ukjent antall tall som summeres. En WHILE-løkke er passende.

// Oppgave 2d)
double inputDouble () {
    double n;
    cout << "Skriv inn et tall:\t";
    cin >> n;
    return n;
}

// Oppgave 2e)
double NOKtoEURO () {
    double kurs = 9.75;
    double n = inputDouble ();
    
    while (n < 0) {
        cout << "Skriv inn et positivt tall" << endl;
        n = inputDouble ();
    }
    cout << n << " NOK tilsvarer ";
    cout << fixed << setprecision (2) << n * kurs << " EURO" << endl;
    return n * kurs;
}

// Oppgave 2f)
    // Jeg velger InputDouble fremfor InputInteger fordi i denne 
    //deloppgaven er det ønskelig å ha desimaltall med to desimalers nøyaktighet.

// Oppgave 2g)
void gangeTabell () {
    int height;
    cout << "Enter height:\t";
    cin >> height;
    
    int width;
    cout << "Enter width:\t";
    cin >> width;

    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            cout << setw (4) << (i + 1) * (j + 1);
        }
        cout << endl;
    }
}

// Oppgave 3a)
double discriminant (double a, double b, double c) {
    return pow (b, 2) - (4 * a * c);
}

// Oppgave 3b)
void printRealRoots (double a, double b, double c) {
    if (discriminant (a, b, c) == 0) {
        cout << "x = " << (double (-b)) / double (2 * a) << endl;
    }
    else if (discriminant (a, b, c) > 0) {
        cout << "x = "
            << double (-b + sqrt (discriminant (a, b, c))) / double (2 * a) 
            << " or x = "
            << double (-b - sqrt (discriminant (a, b, c))) / double (2 * a) << endl;
    }
    else {
        cout << "x har ingen reelle loesninger" << endl;
    }
}

// Oppgave 3c)
void solveQuadraticEquation () {
    double a;
    cout << "a:\t";
    cin >> a;

    double b;
    cout << "b:\t";
    cin >> b;

    double c;
    cout << "c:\t";
    cin >> c;
    
    printRealRoots (a, b, c);
}

// Oppgave 4)
void draw_pytagoras () {
    
    AnimationWindow win{100, 100, 800, 600, "Pytagoras"};

    // Punkter for midten og sidelengdene til trekanten i miden
    int middle_of_screen_X = win.width () / 2;
    int middle_of_screen_Y = win.height () / 2;
    int side_a = 100.0;
    int side_b = 100.0;

    // Punkter for trekant i midten
    Point point1 {middle_of_screen_X - (side_b / 2), middle_of_screen_Y - (side_a / 2)};
    Point point2 {middle_of_screen_X - (side_b / 2), middle_of_screen_Y + (side_a / 2)};
    Point point3 {middle_of_screen_X + (side_b / 2), middle_of_screen_Y + (side_a / 2)};

    // Punkter for kvadrat på side a
    Point point4 {(int) (middle_of_screen_X - (side_b * 1.5)), middle_of_screen_Y - (side_a / 2)};
    Point point5 {(int) (middle_of_screen_X - (side_b * 1.5)), middle_of_screen_Y + (side_a / 2)};

    
    // Punkter for kvadrat side b
    Point point6 {middle_of_screen_X - (side_b / 2), (int) (middle_of_screen_Y + (side_a * 1.5))};
    Point point7 {middle_of_screen_X + (side_b / 2), (int) (middle_of_screen_Y + (side_a * 1.5))};

    // Punkter for kvadrat side c
    Point point8 {middle_of_screen_X + (side_b / 2), (int) (middle_of_screen_Y - (side_a * 1.5))};
    Point point9 {(int) (middle_of_screen_X + (side_b * 1.5)), middle_of_screen_Y - (side_a / 2)};
    

    // Tegning ag trekant i midten
    win.draw_triangle (point1, point2, point3, Color::black);

    // Tegning av kvadrat a
    win.draw_quad (point1, point2, point5, point4, Color::green);

    // Tegning av kvadrat b
    win.draw_quad (point2, point3, point7, point6, Color::red);

    // Tegning av kvadrat c
    win.draw_quad (point1, point3, point9, point8, Color::blue);

    win.wait_for_close ();
}

// Oppgave 5)
vector<int> calculateBalance (int deposit, int interest, int number_of_years) {
    vector<int> balance;

    for (int i = 0; i < number_of_years; i++) {
        double a;
        a =  (double)(deposit) * pow(1.0 + (double)(interest) / 100, i);
        a = static_cast<int> (a);
        balance.push_back (a);
    }
    return balance;
}

// Oppgave 5b)
void printBalance () {
    vector<int> balance = calculateBalance (1000, 30, 20);
    int spaces;

    cout << "Ar" << setw(10) << "Saldo" << '\n';
    for (int i = 0; i < size(balance); i++) {
            if (i < 10) {
                spaces = 10;
            }
            else {
                spaces = 9;
            }
            cout << i << setw (spaces) <<  balance[i] << '\n'; 
    }
}

// Oppgave 5c)
    // Jeg antar at denne feilmeldingen kommer av at man har satt funksjonen til å være av typen int, men forså prøve å returnere en variabel av typen vector<int>

// Oppgave 5d)
void printVector () {
    vector<int> v = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    for (int i = 0; i <= v.size(); i++) {
        cout << v.at(i) << endl;
    }
}
    // Jeg tror feilmeldingen for denne koden skyldes at man iterer utenfor vektoren størrelse.
    // Løser feil ved å bytte ut "<=" med "<" i FOR-løkken.

// menu funksjon
void menu () {
    while (1) {
        cout << "\tMenu\n"
            << "0.\tAvslutt.\n"
            << "1.\tSummere to tall.\n"
            << "2.\tSummere flere tall.\n"
            << "3.\tSkjekk oddetall\n"
            << "4.\tSkriv ut sekunder til timer og minutter.\n"
            << "5.\tKonverter fra NOK til EURO.\n"
            << "6.\tSkriv ut gangetabell fra - til.\n"
            << "7.\tFinn reele roetter\n"
            << "8.\tPytagoras\n"
            << "9.\tBeregn renters rente\n"
            << "10.\tPrint Vektor\n\n"
            << "Angi kommando (0-10):\t";        
        int menu_choice;
        cin >> menu_choice;

        switch (menu_choice) {
            case 0:
                cout << "Du har naa avsluttet. Ha en god dag." << endl;
                return;
                break;
            
            case 1:
                add (2, 5);
                break;

            case 2:
                addSeveralNumbers ();
                break;

            case 3:
                for (int i = 0; i < 15; i++) {
                    cout << (isOdd (i) ? "TRUE\n" : "FALSE\n");
                }
                break;
            
            case 4:
                printHumanReadableTime (10000);
                break;

            case 5:
                NOKtoEURO ();
                break;
            
            case 6:
                gangeTabell ();
                break;

            case 7:
                solveQuadraticEquation ();
                break;
            
            case 8:
                draw_pytagoras ();
                break;

            case 9:
                printBalance ();
                break;
            
            case 10:
                printVector ();
                break;
                
            default:
                cout << "Trykk et tall 0 - 10\n" << endl;
                break;
        }
        cout << "\n";
    }
}

// main funksjon
int main () {
    menu();
    return 0;
}