# include "oppgave2.h"

std::map<char, int> tegnstatistikk (std::string filepath) {
    std::filesystem::path filename {filepath};
    std::ifstream input_stream {filename};

    std::map<char, int> count_char;
    char next_char;

    while (input_stream >> next_char) {
        next_char = tolower (next_char);

        if (isalpha (next_char)) {

            if (count_char.count (next_char)) {
                count_char.at (next_char)++;
            }
            else {
                count_char.insert ({next_char, 1});
            }
        }
    }
    return count_char;
}

void print_map (std::map<char, int> my_map) {
    for (const auto& m:my_map) {
        std::cout << "Key: " << m.first << "\tValue: " << m.second << '\n';
    }
}

string getCapital(const string& country) {
    return capitalsMap.at (country);
}

