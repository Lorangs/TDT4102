# include <iostream>
# include "std_lib_facilities.h"
# include "oppgave1.h"
# include "oppgave2.h"
# include "oppgave3.h"
# include "oppgave4.h"

int main (){
   

// test oppgave 3e)
    //a.read_from_file ("datafil.csv");
    //a.add_course ("TDT4110", "Informasjonsteknologi Grunnkurs");
    //a.add_course ("TDT4102", "Prosedyre- og objektorientert programmering");
    //a.add_course ("TMA4100", "Matematikk 1");
    //a.write_to_new_file ("datafil_V2.csv");

// Oppgave 2a)
    //print_map (tegnstatistikk ("grunnlov.txt"));

// Oppgave 2b)
    //std::cout << "Capitals:" << std::endl;
    //for (pair<const string, const string> elem : capitalsMap) {
    //    cout << getCapital(elem.first) << std::endl;}

// Oppgave 3c)
    //Course_Catalog a;
    //a.add_course ("TDT4110", "Informasjonsteknologi Grunnkurs");
    //a.add_course ("TDT4102", "Prosedyre- og objektorientert programmering");
    //a.add_course ("TMA4100", "Matematikk 1");
    //a.print_content ();



// test av oppgave 4b)
    //std::filesystem::path temperatureFile{"temperatures.txt"};
    //std::ifstream temp_file {temperatureFile};
    //Temps t;
    //temp_file >> t; // t.max = 3.14, t.min = -4.0

// oppgave 4d)
    //std::vector<Temps> temperatures = read_temps ("temperatures.txt");
    //temp_stats (temperatures);

    return 0;
}