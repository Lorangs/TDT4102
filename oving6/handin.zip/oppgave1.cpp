# include "std_lib_facilities.h"
# include <iostream>
# include <string>
# include "oppgave1.h"


// Oppgave 1a)
void write_to_file (){

    std::filesystem::path filename {"oppgave_1a.txt"};
    std::ofstream output_stream {filename};

    std::string new_word;
    std::string q = "quit";
    std::string full_sentence;

    while (new_word != q) {
        std::cout << "Nytt ord:\t";
        std::cin >> new_word;
        if (new_word != q) {
            full_sentence += new_word + '\n';
        }
    }
    output_stream << full_sentence << std::endl;
}

// Oppgave 1b)
void read_from_file () {
    std::filesystem::path filename {"oppgave_1a.txt"};
    std::filesystem::path new_file {"oppgave_1b.txt"};
    std::ifstream input_stream;
    input_stream.open (filename);
    std::ofstream output_stream {new_file};


    if (input_stream) {
        std::string next_line;
        int count = 0;

        while (getline (input_stream, next_line)) {
            count++;
            output_stream << count << '\t' << next_line << std::endl;
        }
    }
    else {
        std::cout << "Filen eksisterer ikke." << std::endl;
    }
}