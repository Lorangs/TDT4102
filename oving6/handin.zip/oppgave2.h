#pragma once
# include <string>
# include <iostream>
# include <map>
# include "std_lib_facilities.h"

std::map<char, int> tegnstatistikk (std::string filepath);
void print_map (std::map<char, int> my_map);
std::string getCapital (const std::string& country);

const std::map<std::string, std::string> capitalsMap {
    {"Norway", "Oslo"},
    {"Sweden", "Stockholm"},
    {"Denmark", "Copenhagen"}
};
