# pragma once

void write_to_file ();
void read_from_file ();