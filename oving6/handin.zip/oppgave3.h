# pragma once
# include <string>
# include <unordered_map>
# include <iostream>
# include "std_lib_facilities.h"

class Course_Catalog {
    std::unordered_map<std::string, std::string> emnekode;
public:
    //Course_Catalog ();
    void read_from_file (std::string filepath);
    void write_to_new_file (std::string filepath);
    void add_course (std::string kode, std::string name);
    void add_course_V2 (std::string kode, std::string name);
    void remove_course (std::string kode);
    std::string get_course (std::string kode);
    void print_content ();
    friend ostream& operator<< (ostream& os, const Course_Catalog& emnekode);
};

void add_element ();