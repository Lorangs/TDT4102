# include "oppgave3.h"
# include <cstring>


void Course_Catalog::add_course (std::string kode, std::string name) {
    if (emnekode.count (kode)) {
        std::cout << "Dette emnet er allerede oppdatert" << std::endl;
    }
    else {
        emnekode.insert ({kode, name});
    }    
}


void Course_Catalog::remove_course (std::string kode) {
    bool ans = 1;
    std::cout << "Er du sikker du vil fjernet " << kode << " ? (1/0)";
    std::cin >> ans;

    if (ans) {
        emnekode.erase (kode);
    }
}

std::string Course_Catalog::get_course (std::string kode){
    return emnekode.at (kode);
}

void Course_Catalog::print_content () {
    for (pair<const std::string, const std::string> elem : emnekode) {
        std::cout << elem.first << "\t" << elem.second << std::endl;
    } 
}

// oppgave 3c)
void add_element () {
    Course_Catalog a;
    a.add_course ("TDT4110", "Informasjonsteknologi Grunnkurs");
    a.add_course ("TDT4102", "Prosedyre- og objektorientert programmering");
    a.add_course ("TMA4100", "Matematikk 1");
    a.print_content ();
}

// Oppgave 3d)
    // Dette blir tull :()
void Course_Catalog::add_course_V2 (std::string kode, std::string name) {
    emnekode[kode] = name;   
}

// Oppgave 3e)
void Course_Catalog::read_from_file (std::string filepath) {
    std::filesystem::path filename {filepath};
    std::ifstream input_stream {filename};

    if (input_stream) {
        std::string next_line;

        while (getline (input_stream, next_line)) {
            std::string key = next_line.substr (0, next_line.find(','));
            std::string value = next_line.substr (next_line.find(',') + 1);
            emnekode.insert ({key, value});
        }
    }
    else {
        std::cout << "Filen eksisterer ikke." << std::endl;
    }
}


void Course_Catalog::write_to_new_file (std::string filepath) {
    std::filesystem::path filename {filepath};
    std::ofstream output_stream {filename};

    for (pair<const std::string, const std::string> elem : emnekode) {
        output_stream << elem.first << "," << elem.second << std::endl;
    }
}




