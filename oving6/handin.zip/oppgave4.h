# pragma once
# include <iostream>
# include <vector>
# include "std_lib_facilities.h"

struct Temps {
    double max;
    double min;
friend istream& operator>> (istream& is, Temps& t);
friend ostream& operator<< (ostream& os, Temps& t);
};

std::vector<Temps> read_temps (std::string filepath);
void temp_stats (std::vector<Temps> t);
