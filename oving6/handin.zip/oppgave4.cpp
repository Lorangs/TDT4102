# include "oppgave4.h"

istream& operator>> (istream& is, Temps& t) {
    is >> t.max >> t.min;
    return is;
}

ostream& operator<< (ostream& os, Temps& t) {
    os << t.max << t.min;
    return os;
}

std::vector<Temps> read_temps (std::string filepath) {
    std::filesystem::path filename {filepath};
    std::ifstream input_stream {filename};

    std::vector<Temps> temperatures;
    Temps t;

    if (input_stream) {
        while (input_stream >> t) {
            temperatures.push_back (t);
        }
    }
    else {
        std::cout << "Filen ble ikke funnet" << std::endl;
    }

    return temperatures;
}

void temp_stats (std::vector<Temps> t) {
    double maksimum, minimum = 0.0;
    int maksimum_index, minimum_index;

    for (size_t i = 0; i < t.size (); i++) {
        if (t.at (i).max > maksimum) {
            maksimum = t.at (i).max;
            maksimum_index = i + 1;
        }
        else if (t.at (i).min < minimum) {
            minimum = t.at (i).min;
            minimum_index = i + 1;
        }      
    }

    std::cout << "Makstempratur var:\t" << maksimum << '\n'
    << "pa dag nr:\t" << maksimum_index << '\n'
    << "Minimumtempratur var:\t" << minimum << '\n'
    << "pa dag nr:" << minimum_index << '\n';
}
