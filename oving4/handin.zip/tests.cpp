# include "std_lib_facilities.h"
# include "file1.h"
# include "mastermind.h"

// Oppgave 1c)
void testCallByValue () {
    int v0 = 5;
    int increment = 2;
    int iteratrions = 10;
    int result = incrementByValueNumTimes (v0, increment, iteratrions);
    std::cout << "$v_0$: " << v0
    << " increment: " << increment
    << " iterations: " << iteratrions
    << " result: " << result << std::endl;
}

void testCallByReference () {
    int v0 = 5;
    int increment = 2;
    int iteratrions = 10;
    int result = incrementByValueNumTimesRef (v0, increment, iteratrions);
    std::cout << "$v_0$: " << v0
    << " increment: " << increment
    << " iterations: " << iteratrions
    << " result: " << result << std::endl;
}

// OPpgave 3a)
void testString () {
    std::string grades = randomizeString (8, 'A', 'F');
    std::vector<int> gradeCount = {
    countChar (grades, 'A'), 
    countChar (grades, 'B'), 
    countChar (grades, 'C'), 
    countChar (grades, 'D'), 
    countChar (grades, 'E'), 
    countChar (grades, 'F')
    };

    double snitt = 0;
    std::cout << "Karakterene er antall #A,#B,#C,#C,#D,#E,#F:\n";
    for (int i = 0; i < 6; i++) {
        std::cout << gradeCount.at (i);
        snitt += gradeCount.at(i) * (5.0 - i);
    }
    snitt /= 6; 
    std::cout << fixed << "\nSnittkarakteren er:\t" << setprecision(2) << snitt << std::endl;
}

