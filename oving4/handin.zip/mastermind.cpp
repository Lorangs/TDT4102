# include "file1.h"
# include "std_lib_facilities.h"
# include "tests.h"
# include <string>
# include "masterVisual.h"

int checkCharacters (std::string code, std::string guess) {

    int countCharInCode = 0;
    for (int i = 0; i < code.size (); i++) {
        if (code.find (guess.at (i)) != std::string::npos) {
            countCharInCode++;
        }
    }
    return countCharInCode;
}
int checkCharactersInRightPosition (std::string code, std::string guess) {
    int countCharInRightPlace = 0;
    for (int i = 0; i < code.size (); i++) {
        if (code.at (i) == guess.at (i)) {
            countCharInRightPlace++; 
        }
    }
    return countCharInRightPlace;
}



// Oppgave 4a)
void playMastermind () {
    constexpr int size = 4;
    constexpr int letters = 6;
    constexpr int numLives = 5;

    std::string code = randomizeString (size, 'A', ('A' + letters - 1));
    std::cout << "code " << code << std::endl;
    

    int tries = 0;
    std::string guess = readInputToString (size, 'A', ('A' + letters - 1));  

    int CharInCode = checkCharacters (code, guess);
    int CharInRightPlace = checkCharactersInRightPosition (code, guess);

    while (tries < numLives) {
        std::cout   << "Du har\t" << CharInCode << " riktige bokstaver\n"
                    << "Du har\t" << CharInRightPlace << " riktige bokstaver pa riktig plass" << std::endl;

        guess = readInputToString (size, 'A', ('A' + letters - 1)); 
        tries++; 

        CharInCode = checkCharacters (code, guess);
        CharInRightPlace = checkCharactersInRightPosition (code, guess);

        if (CharInRightPlace < size) {
            std::cout << "\nDette var du darlig pa.\nProv igjen!" << std::endl;
        }  
        else if (CharInRightPlace == size) {
            std::cout << "Gratulerer!\nDu har vunnet MasterMind!\nPa kun " << tries << " forsok!" << std::endl;
            break;
        }
    }
    if (tries < numLives) {
        std::cout << "\nBeklager, du tapte din Taper!\nStart nytt spill og prov igjen." << std::endl;
    }
}


