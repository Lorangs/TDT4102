# include "std_lib_facilities.h"
# include <iostream>
# include <random>
# include "file1.h"
# include "mastermind.h"
# include "masterVisual.h"

// Oppgave 1b)
int incrementByValueNumTimes (int startValue, int increment, int numTimes) {
    for (int i = 0; i < numTimes; i++) {
        startValue += increment;
    }
    return startValue;
}

// Oppgave 1d)
int incrementByValueNumTimesRef (int& startValue, int increment, int numTimes) {
for (int i = 0; i < numTimes; i++) {
        startValue += increment;
    }
    return startValue;
}

// Oppgave 1e)
void swapNumbers (int& a, int& b) {
    std::cout 
    << "a foer endring: " << a << '\n'
    << "b foer endring: " << b << std::endl;

    int temp = a;
    a = b;
    b = temp;

    std::cout 
    << "a etter endring: " << a << '\n'
    << "b etter endring: " << b << std::endl;
}

// Oppgave 2b)
void printStudent (Student stud) {
    std::cout << "Name:\t\t" << stud.name << '\n'
    << "Program:\t" << stud.studyProgram << '\n'
    << "Age:\t\t" << stud.age << std::endl;
}

// Oppgave 2c)
bool isInProgram (Student stud, std::string nameCheck) {
    if (nameCheck == stud.name) {
        return 1;
    }
    else {
        return 0;
    }
}

// Oppgave 3b)
int randomWithLimits (int lower, int upper) {
    std::uniform_int_distribution<int> distribution (lower, upper);
    std::random_device random;
    std:: default_random_engine generator (random ());

    return distribution (generator);
}

std::string randomizeString (int numInString, char LowerLimit, char UpperLimit) {
    int lowerASCII = int (LowerLimit);
    int upperASCII = int (UpperLimit);

    std::string word = "";
    for (int i = 0; i < numInString; i++) {
        std::string letter = {char (randomWithLimits (lowerASCII, upperASCII))};
        word += letter;
    }
    return word;
}

// Oppgave 3d)
std::string readInputToString (int numLengthString, char LowerLimit, char UpperLimit) {
    LowerLimit = toupper (LowerLimit);
    UpperLimit = toupper (UpperLimit);

    std::string word = "";
    for (int i = 0; i < numLengthString; i++) {
        char a;
        std::cout << "Skriv inn enbokstav mellom " << LowerLimit << " og " << UpperLimit << " for ordet pa " << numLengthString << " bokstaver:\t";
        std::cin >> a;
        a = toupper (a);

        while (a < LowerLimit or a > UpperLimit) {
            std::cout << "Skriv inn enbokstav mellom " << LowerLimit << " og " << UpperLimit << '\t';
            std::cin >> a;
            a = toupper (a);
        }
        std::string letter = {char (a)};
        word += letter;
    }
    std::cout << word << std::endl;
    return word;
}   

// Oppgave 3e)
int countChar (std::string word, char letter) {
    int count = 0;
    for (int i = 0; i < int (size (word)); i++) {
        if (letter == word.at(i)) {
            count++;
        }
    }
    return count;
}

// Oppgave 3f)
