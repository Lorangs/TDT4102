# pragma once
# include <string>

int incrementByValueNumTimes (int startValue, int increment, int numTimes);
int incrementByValueNumTimesRef (int& startValue, int increment, int numTimes);
void swapNumbers (int& a, int& b);

// Oppgave 2a)
struct Student{
    std::string name;
    std::string studyProgram;
    int age;
};

void printStudent (Student stud);
bool isInProgram (Student stud, std::string nameCheck);
int randomWithLimits (int lower, int upper);
std::string randomizeString (int numInString, char LowerLimit, char UpperLimit);
std::string readInputToString (int numLengthString, char LowerLimit, char UpperLimit);
int countChar (std::string word, char letter);
