# pragma once

int checkCharacters (std::string code, std::string guess);
int checkCharactersInRightPosition (std::string code, std::string guess);
void playMastermind ();

