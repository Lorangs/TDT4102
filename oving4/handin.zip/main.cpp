# include "std_lib_facilities.h"
# include <iostream>
# include "tests.h"
# include "file1.h"
# include "mastermind.h"
# include "masterVisual.h"



// tall for oppgave 1e)
int a = 4;
int b = 8;


// student for oppgave 2d)
Student stud {"Kevin 'Thad' Castle", "Chicks", 69};
string nameCheck = "Kevin 'Thad' Castle";



// menu funksjon
void menu () {
    while (1) {
        std::cout << "\tMenu\n"
            << "0.\tAvslutt.\n"
            << "1.\tTest Verdi.\n"
            << "2.\tTest Referanse.\n"
            << "3.\tSwap Numbers.\n"
            << "4.\tPrint Student.\n"
            << "5.\tEr studenten en student?\n"
            << "6.\tLag et vilkarlig ord.\n"
            << "7.\tSkriv inn et ord\n"
            << "8.\tTest String\n"
            << "9.\tSpill MasterMind.\n"
            << "10.\tSpill MasterMin Visual\n\n"
            << "Angi kommando (0-9):\t";        
        int menu_choice;
        std::cin >> menu_choice;

        switch (menu_choice) {
            case 0:
                std::cout << "Du har na avsluttet. Ha en god dag." << std::endl;
                return;
                break;
            
            case 1:
                testCallByValue ();
                break;

            case 2:
                testCallByReference ();
                break;

            case 3:
                swapNumbers (a, b);
                break;
            
            case 4:
                printStudent (stud);
                break;

            case 5:
                if (isInProgram (stud, nameCheck)) {
                    std::cout << nameCheck << " is a student" << std::endl;
                }
                else {
                    std::cout << nameCheck << " is not a student" << std::endl;
                }
                break;
            
            case 6:
                testString ();
                break;

            case 7:
                readInputToString (4, 'a', 'e');
                break;
            
            case 8:
                testString ();
                break;

            case 9:
                playMastermind ();
                break;
            
            case 10:   
                playMasterMindVisual ();
                break;
                
            default:
               
                break;
        }
        std::cout << "\n";
    }
}


int main () {
    menu ();
    return 0;
}

// Oppgave 2e)
    // Feilmelding (error: redefinition of 'Student') skjerf fordi struct Studdent blir 
    // definert to ganger ved at man inkluderer file1.h og sammtidig definerer struct 'Student i .cpp fila