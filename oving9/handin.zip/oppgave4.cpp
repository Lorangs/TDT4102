# include "oppgave4.h"

Meeting_Window::Meeting_Window (Point win_position, int w, int h, const std::string &title) :
            quit_btn {{w_width - pad - btn_width, pad}, btn_width, btn_height, btn_quit_label}, 
            add_person_btn {{field_pad, 3 * pad + 2 * field_height}, btn_width, btn_height, btn_add_label},
            person_name {{field_pad, pad}, field_width, field_height, field_name_label},
            person_email {{field_pad, 2 * pad + field_height}, field_width, field_height, field_email_label},
            AnimationWindow {win_position.x, win_position.y, w, h, title}
               
        {
            add (quit_btn);
            quit_btn.setCallback (std::bind (&Meeting_Window::cb_quit, this));
            add (add_person_btn);
            add_person_btn.setCallback (std::bind (&Meeting_Window::cb_add_person, this)); 

            add (person_name);

            add (person_email);
        };

void Meeting_Window::cb_quit () {
    std::cout << "Goodbye" << std::endl;
    this -> close ();
}

void Meeting_Window::cb_add_person () {
    new_person ();
}

void Meeting_Window::new_person () {
    std::string name = person_name.getText ();
    std::string email = person_email.getText (); 
    if (name == "" || email == "" || name == field_name_label || email == field_email_label) {
        std::cout << "vennligst legg inn fullstendig informasjon i begge tekstfelt" << std::endl;
    }
    else {
        people.emplace_back (new Person {name, email});
        person_name.setText ("name:");
        person_email.setText ("email:");  
        std::cout << "name:" << name << '\n'
        << "email:" << email << '\n'
        << "Person was sucseccfully added" << std::endl;
    }
}

void Meeting_Window::print_people () {
    for (std::shared_ptr<Person> p : people) {
        std::cout << p;
    }
}