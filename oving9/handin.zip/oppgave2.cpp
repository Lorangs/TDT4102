# include "oppgave2.h"

void Person::set_name (std::string &n) {
    name = n;
}

void Person::set_email (std::string &e) {
    email = e;
}

std::string Person::get_name () const {
    return name;
}

std::string Person::get_email () const {
    return email;
}

bool Person::has_available_seats () const {
    if (car_ptr.get () != nullptr && car_ptr.get () -> get_seats () > 0) {
        return 1;
    }
    else {
        return 0;
    }
}

int Person::num_seats () const {
    if (car_ptr.get() != nullptr) {
        return car_ptr.get() -> get_seats ();
    }
    else {
        return -1;
    }
}

void operator<< (std::ostream &os, const Person &p) {
    os << "Name:" << "\t\t\t" << p.get_name () << '\n'
    << "E-mail:" << "\t\t\t" << p.get_email () << '\n'
    << "Number of Seats:" << "\t" << p.num_seats () << '\n';
}

