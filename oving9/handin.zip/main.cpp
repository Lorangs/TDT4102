# include "oppgave1.h"
# include "oppgave2.h"
# include "oppgave3.h"
# include "oppgave4.h"


/* oppgave 2d)
Denne parameteren er deklarert som const fordi den ikke skal
endre noen av medlemsvariablene.
*/

/* oppgave 3e)
Minnet vi allokerer med pointerne våre blir slettet i det shared ptr objektet Person går ut av skop.
Dette gjelder for alle shared ptr som deler adresse til samme person.
*/




int main () {
    std::unique_ptr<Car> car_1 {new Car {4}};
    std::unique_ptr<Car> car_2 {new Car {1}};
    std::unique_ptr<Car> car_3 {new Car {0}};

    Person p;
    Person q ("Ing. Olga Polkova", "Olga.P@elBedrift.ru", std::move(car_1));
    Person w ("Hans Pettersen", "Hans@pettersen.no", std::move (car_2));
    std::cout << p;
    std::cout << q;
    std::cout << w;

    Meeting_Window window (Meeting_Window::win_pos, Meeting_Window::w_width, Meeting_Window::w_height, Meeting_Window::titel);
    window.wait_for_close ();


    return 0;
}