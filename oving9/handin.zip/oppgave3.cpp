# include "oppgave3.h"

std::ostream &operator<< (std::ostream &os, const Campus &c) {
    if (c == Campus::Trondheim) {
        os << "Trondheim";
    }
    else if (c == Campus::Gjovik) {
        os << "Gjøvik";
    }
    else if (c == Campus::Aalesund) {
        os << "Aalesund";
    }
    return os;
}

std::vector<std::string> Meeting::get_participants_list () const {
    std::vector<std::string> name_list;
    for (std::shared_ptr<Person> p : participants) {
        name_list.push_back (p -> get_name ());
    }
    return name_list;
}


void Meeting::add_participant (std::shared_ptr<Person> p) {
    participants.push_back (p);
}

std::ostream &operator<< (std::ostream &os, const Meeting &M) {
    os << "Subject:\t" << M.get_subject () << '\n'
    << "Location:\t" << M.get_location () << '\n'
    << "Start time:\t" << M.get_start_time () << '\n'
    << "End time:\t" << M.get_end_time () << '\n'
    << "Leader:\t" << M.get_leader () -> get_name () << '\n'
    << "Participants:";
    for (std::string p : M.get_participants_list ()) 
    {
        os << '\n' << p;
    }; 
    return os;
}

std::vector<std::shared_ptr<Person>> Meeting::find_potential_codriving (Meeting &M) {
    std::vector<std::shared_ptr<Person>> potential;

    for (std::shared_ptr<Person> p : participants) {

        if (p -> has_available_seats () 
            && location == M.get_location ()
            && day == M.get_day ()
            && M.get_start_time () - 1 <= start_time <=  M.get_start_time () + 1
            && M.get_end_time () - 1 <= end_time <= M.get_end_time () + 1) 
        {
            potential.push_back (p);
        }
    }
    return potential;
}