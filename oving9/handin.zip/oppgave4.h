# pragma once
# include "AnimationWindow.h"
# include "widgets/TextInput.h"
# include "widgets/Button.h"
# include <string>
# include <iostream>
# include "point.h"
# include "oppgave2.h"

class Meeting_Window : public TDT4102::AnimationWindow {
    private:
        inline static const std::string btn_quit_label = "exit";
        inline static const std::string btn_add_label = "add person";
        inline static const std::string field_name_label = "name:";
        inline static const std::string field_email_label = "email:";
        TDT4102::Button quit_btn;
        TDT4102::Button add_person_btn;
        TDT4102::TextInput person_name;
        TDT4102::TextInput person_email;
        std::vector<std::shared_ptr<Person>> people;

    public:
        Meeting_Window (Point win_position, int w, int h, const std::string &title);
        void cb_quit ();
        void cb_add_person ();
        void new_person ();
        void print_people ();

        static constexpr int w_width = 500;
        static constexpr int w_height = 300;
        static constexpr int pad = 20;
        static constexpr int btn_width = 60;
        static constexpr int btn_height = 40;
        static constexpr int field_width = 120;
        static constexpr int field_height = 40;
        static constexpr int field_pad = 60;
        static constexpr Point win_pos {50, 50};
        inline static const std::string titel = "NTNU samkjoring";
};