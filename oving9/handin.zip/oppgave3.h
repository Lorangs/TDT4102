# pragma once
# include <string>
# include <iostream>
# include <memory>
# include <vector>
# include "oppgave2.h"

enum class Campus {Trondheim = 0, Gjovik, Aalesund};
std::ostream &operator<< (std::ostream &os, const Campus &c);

class Meeting {
    private:    
        int day;
        int start_time;
        int end_time;
        Campus location;
        std::string subject;
        const std::shared_ptr<Person> leader;
        std::vector<std::shared_ptr<Person>> participants;

    public:
        Meeting (int d, int s_time, int e_time, Campus loc, std::string sub, const std::shared_ptr<Person> lead) :
            day {d},
            start_time {s_time},
            end_time {e_time},
            location {loc},
            subject {sub},
            leader {lead} 
        {
            participants.push_back (leader);
        };
        int get_day () const {return day;};
        int get_start_time () const {return start_time;};
        int get_end_time () const {return end_time;};
        Campus get_location () const {return location;};
        std::string get_subject () const {return subject;}; 
        std::shared_ptr<Person> get_leader () const {return leader;};

        std::vector<std::string> get_participants_list () const;  
        void add_participant (std::shared_ptr<Person> p);
        std::vector<std::shared_ptr<Person>> find_potential_codriving (Meeting &M);
};

std::ostream &operator<< (std::ostream &os, const Meeting &M);
