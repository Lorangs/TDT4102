# pragma once
# include "Oppgave1.h"
# include <string>
# include <memory>
# include <iostream>


class Person {
    private:
        std::string name;
        std::string email;
        std::unique_ptr<Car> car_ptr;

    public:
        Person () : name {"Navn Navnesen"}, email {"navn@navnesen.no"}, car_ptr {nullptr} {};
        Person (std::string n, std::string e, std::unique_ptr<Car> c = nullptr) : name {n}, email {e}, car_ptr {std::move (c)} {};
        ~Person () {};
        void set_name (std::string &n);
        void set_email (std::string &e);
        std::string get_name () const;
        std::string get_email () const;
        bool has_available_seats () const;
        int num_seats () const;
    
    friend void operator<< (std::ostream &os, const Person &p);
};