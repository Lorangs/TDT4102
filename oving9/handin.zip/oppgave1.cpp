# include "oppgave1.h"

bool Car::has_free_seat () const {
    if (free_seats > 0) {
        return 1;
    }
    else {
        return 0;
    }
}

int Car::get_seats () const {
    return free_seats;
}

void Car::reserve_seat () {
    assert (free_seats > 0);
    free_seats--;
}

void Car::reserve_num_seats (int num) {
    assert (free_seats >= num);
    free_seats -= num;   
}