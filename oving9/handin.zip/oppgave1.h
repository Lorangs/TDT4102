# pragma once
# include <cassert>


class Car {
    private:
        int free_seats;

    public:
        Car (int f_seats) : free_seats {f_seats} {};
        bool has_free_seat () const;
        int get_seats () const;
        void reserve_num_seats (int num);
        void reserve_seat ();  
};

