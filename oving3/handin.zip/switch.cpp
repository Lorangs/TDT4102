#include "std_lib_facilities.h"
#include "cannonball.h"
#include "oppgave_3.h"
#include "switch.h"

void meny () {
    cout << "\tMeny:\n"
        << "0.\tAvslutt.\n"
        << "1.\tTest kode etter hensikt.\n"
        << "2.\tskriv ut lengde på kanonskudd.\n\n"
        << "\tAngi kommando:\t";

    int choice;
    cin >> choice;

    switch (choice) {
        case 0: 
            cout << "Du har naa avsluttet. Ha en god dag." << endl;
            break;
            
        case 1:
            testDeviation (posX (0.0, 50.0, 5.0), 250.0, 0.1, "posX");
            testDeviation (posY (0.0, 25.0, 5.0), 2.375, 0.1, "posY"); 
            testDeviation (velX (50.0, 5.0), 50.0, 0.1, "velX");
            testDeviation (velY (25.0, 5.0), -24.05, 0.1, "velY"); 
            break;

        case 2:
            
            break;

        default:
            break;
    }
}