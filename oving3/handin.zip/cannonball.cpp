# include "std_lib_facilities.h"
# include "cannonball.h"
# include "utilities.h"
# include "cannonball_viz.h"

// Jordas gravitasjonskraft
double acclY () {
    return -9.81;
}

// trekk kraft i x-retning
double acclX () {
    return 0.0;
}

// fart i y-retning
double velY (double initVelocity, double time) {
    return initVelocity + acclY() * time;
}
// fart i x-retning
double velX (double initVelocity, double time) {
    return initVelocity + acclX() * time;
}
// posisjon i x-retning
double posX (double initPosition, double initVelocity, double time) {
    return initPosition + initVelocity * time + (acclX() * pow (time, 2)) / 2.0;
}
// posisjon i y-retning
double posY (double initPosition, double initVelocity, double time) {
    return initPosition + initVelocity * time + (acclY() * pow (time, 2)) / 2.0;
}
// skriver ut tid
void printTime (double time) {
    int t = static_cast<int> (time);
    int hour = t / 3600;
    int min = (t % 3600) / 60;
    int sek = t % 60;
    cout << hour << " hours " << min << " minuets " << sek << " sekunds.\n";
}
// finner flytid
double flightTime (double initVelocityY) {
    return (-2.0 * initVelocityY) / acclY ();
}

// Ber brukeren om en vinkel
// True om vinkelmål er i rad.
// False om vinkelmål er i degrees.
double getUserInputTheta (bool rad) {
    cout << "Skriv inn utskytningsvinkel i grader:\t";
    double Theta;
    cin >> Theta;
    if (rad) {
        return Theta;
    }
    else {
        return degToRad (Theta);
    }
    
}
// Ber brukeren om en absoluttfart
double getUserInputAbsVelocity () {
    cout << "Skriv inn starthastighet:\t\t";
    double v;
    cin >> v;
    return v;
}
// Konverteerer fra grader til radianer
double degToRad (double deg) {
    return deg / 180 * M_PI;
}
// Returnerer farten gitt av absVelocity, i x- og y-komponentene
double getVelocityX (double theta, double absVelocity) {
    return absVelocity * cos(theta);
}
double getVelocityY (double theta, double absVelocity) {
    return absVelocity * sin(theta);
}

// Dekomponerer farten gitt av absVelocity, i x- og y-komponentene
    // gitt vinkelen theta. Det første elementet i vectoren skal være
    //x-komponenten, og det andre elementet skal være y-komponenten.
    // "Vector" i funksjonsnavnet er vektor-begrepet i geometri
vector<double> getVelocityVector (double theta, double absVelocity) {
    vector<double> v {getVelocityX (theta, absVelocity), getVelocityY (theta, absVelocity)};
    return v;
}

// finner avstand reist
double getDistanceTraveled (double velocityX, double velocityY) {
    double fTime = flightTime (velocityY);
    return posX (0.0, velocityX, fTime);
}

// finner avviket fra treff til blink
// Positive verdier viser meter for langt unna mål
// negative verdier viser meter for kort fra mål
double targetPractice (double distanceToTarget, double velocityX, double velocityY) {
    double distanceShot = getDistanceTraveled (velocityX, velocityY);
    return distanceShot - distanceToTarget;
}

void playTargetPractice() {
    cout << "Velkomment til spillet Target Practice\n"
    << "Du har 10 forsok pa a treffe blink med en noyaktighet pa 5 meter\n"
    << "Blinken er plassert en plass mellom 100 og 1000 meter unna."
    "Lykke til!" << endl;

    double target = randomWithLimits (100.0, 1000.0);
    cout << "Malet er " << target << " meter unna" << endl;

    bool WinnerWinnerChickenDinner = 0;

    for (int i = 0; i < 10; i++) {
        cout << "\nDu har " << 10 - i << " forsok igjen." << endl;

        double userTheta = getUserInputTheta (false);
        double userAbsVelocity = getUserInputAbsVelocity ();

        vector<double> velocityVector = getVelocityVector (userTheta, userAbsVelocity);
        double distanceFromTarget = targetPractice (target, velocityVector.at(0), velocityVector.at(1));

        cannonBallViz (target, 1000, velocityVector.at(0), velocityVector.at(1), 50);
        
        if (abs (distanceFromTarget) <= 5) {
            WinnerWinnerChickenDinner = 1;
            cout << "\nGratulerer du har vunnet!\n"
            << "Kanksje du er noe vettugt tross alt" << endl;
            break;
        }
        else {
            cout << "Bom.\tDu er " << distanceFromTarget << " meter unna malet. Prov igjen." << endl;
        }
    }

    if (WinnerWinnerChickenDinner == 0) {
        cout << "Du ma stille inn siktet ditt bedre din taper!\n"
        << "Treffer ikke en lavedor på kloss hold!\n"
        << "Dra hjem dit du kom fra bygutt, og kom tilbake nar du har ovd mer." << endl;
    }
}
      