# pragma once
void meny ();