# include "std_lib_facilities.h"
# include "myfunctions.h"
# include "cannonball.h"
# include "oppgave_3.h"
# include "switch.h"
# include "utilities.h"
# include "cannonball.h"

int main () {
    playTargetPractice ();
    return 0;
}