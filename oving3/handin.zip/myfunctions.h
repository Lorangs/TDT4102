# pragma once

int add (int a, int b);
void printAdd (int a, int b);