# include "std_lib_facilities.h"
# include <random>


double randomWithLimits (double lowerLim, double upperLim) {

std::uniform_real_distribution<double> distribution(lowerLim, upperLim);
std::random_device rd;
std::default_random_engine generator(rd());
return distribution(generator);
}   