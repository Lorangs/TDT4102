# include "std_lib_facilities.h"
# include "oppgave_3.h"
# include "cannonball.h"

void testDeviation (double compareOprand, double toOprand, double maxError, string name) {
    if (abs (compareOprand - toOprand) <= maxError) {
        cout << compareOprand << " is valid answer for " << name << endl;
    }
    else {
        cout << name << " is no valid, expected " << toOprand << " got " << compareOprand << endl;
    }
}

bool checkIfDistanceToTargetIsCorrect () {
    double error = targetPractice(0, 0, 0);
    return error == 0;
}