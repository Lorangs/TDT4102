# pragma once

void testDeviation (double compareOprand, double toOprand, double maxError, string name);
bool checkIfDistanceToTargetIsCorrect ();