# include "std_lib_facilities.h"
# include "myfunctions.h"

int add (int a, int b) {
    return a + b;
}

void printAdd (int a, int b) {
    cout << add (a, b) << '\n';
}