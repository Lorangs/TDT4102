# pragma once
double randomWithLimits (double lowerLim, double upperLim);