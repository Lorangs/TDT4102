# pragma once
# include <vector>
# include "card.h"

class Card_Deck {
private:
    std::vector<Card> cards;
    void swap (int a, int b);
    
public:
    Card_Deck ();
    void print_deck ();
    Card draw_card ();
    void shuffle ();
};