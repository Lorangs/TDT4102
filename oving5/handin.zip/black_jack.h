# pragma once
# include "card_deck.h"
# include "card.h"

class Black_Jack {
private:
    Card_Deck deck;
    std::vector<Card> player_hand;
    std::vector<Card> dealer_hand;
    int player_hand_sum = 0;
    int dealer_hand_sum = 0;
 
public:
    Black_Jack (Card_Deck d);
    int get_card_value (Card card);
    int get_hand_score (std::vector<Card> hand);
    bool ask_player_draw_card ();
    void draw_player_card ();
    void draw_dealer_card ();
    void play_game ();
};

bool is_ace (Card card);