# pragma once
# include <string>
# include <unordered_map>

// Oppgave 1a)
enum class Suit {clubs, diamonds, hearts, spades};

// Oppgave 1b)
enum class Rank {two = 2, three, four, five, six, seven, eight, nine, ten, jack, queen, king, ace};


// Oppgave 2a)
class Card {
private:
    Suit s;
    Rank r;
public:
    Card (Suit suit, Rank rank);
    Suit get_suit ();
    Rank get_rank ();
    std::string to_string ();
};

std::string suit_to_string (Suit suit);
std::string rank_to_string (Rank rank);