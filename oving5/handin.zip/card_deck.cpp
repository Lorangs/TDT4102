# include "card.h"
# include <vector>
# include "card_deck.h"
# include <iostream>
# include "std_lib_facilities.h"
# include <random>

// Oppgave 3b)
Card_Deck::Card_Deck () {
    for (int i = 0; i < 4; i++) {
        for (int j = 2; j < 15; j++) {
            Card card = Card (static_cast<Suit> (i), static_cast<Rank> (j));
            cards.push_back (card);
        }
    }
}

// Oppgave 3c)
void Card_Deck::swap (int a, int b) {
    Card temp = cards.at (a);
    cards.at (a) = cards.at (b);
    cards.at (b) = temp;
}

// Oppgave 3d)
void Card_Deck::print_deck () {
    for (int i = 0; i < cards.size (); i++) {
        std::cout << cards.at (i).to_string () << '\n';
    }
}

// Oppgave 3e)
void Card_Deck::shuffle () {
    random_device random;
    default_random_engine engine (random ());
    uniform_int_distribution dist (0, 51);

    for (int i = 0; i < 1000; i++) {
        Card_Deck::swap (dist (engine), dist (engine));
    }
}

// Oppgave 3f)
Card Card_Deck::draw_card () {
    Card last_card = cards.at(cards.size () - 1);
    cards.pop_back ();
    return last_card;
}
