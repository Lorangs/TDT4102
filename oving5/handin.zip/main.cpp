# include <iostream>
# include <vector>
# include "card.h"
# include "card_deck.h"
# include "black_jack.h"


// Oppgave 1e)
    // Fordel med å bruke symboler for farge og verdi er for å forsikre om ikke å missforstå resultatene.
    // eksempelvis vil et resultat Two of Clubs kunne tolkes som heltall 2 0
    // Dette kan fort forvekses med tallet 20 som betyr noe helt annet.



void meny () {  
    while (1) {
        std::cout << "\tMeny:\n"
            << "0.\tAvslutt.\n"
            << "1.\tTest Rank og Suit\n"
            << "2.\tTest Class Rank og Suit\n"
            << "3.\tTest Deck og shuffle\n"
            << "4.\tPlay Black Jack\n\n"
            << "\tAngi kommando:\t";

        int choice;
        std::cin >> choice;

        switch (choice) 
        {
            case 0:
                std::cout << "Du har na avsluttet. Ha en god dag." << std::endl;
                return;
                break;

            case 1:
                // Oppgave 1f)
                {
                Rank r = Rank::king;
                Suit s = Suit::hearts;
                std::string rank = rank_to_string (r);
                std::string suit = suit_to_string (s);
                std::cout << "Rank: " << rank << " Suit: " << suit << '\n';
                }
                break;
            
            case 2:
                {
                // Oppgave 2f)
                Card c{Suit::spades, Rank::ace};
                std::cout << c.to_string () << std::endl;
                }
                break;

            case 3:
                {
                Card_Deck deck = Card_Deck ();
                deck.print_deck ();
                deck.shuffle ();
                deck.print_deck ();
                }

            case 4:
                {
                Card_Deck deck = Card_Deck ();
                Black_Jack b (deck);
                b.play_game ();
                }
            default:
                break;
        }
    } 
}

int main () {
    meny ();
    return 0;
}