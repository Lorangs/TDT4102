# include"black_jack.h"
# include "std_lib_facilities.h"

Black_Jack::Black_Jack (Card_Deck d) : deck{d} {}

bool is_ace (Card card) {
    if (card.get_rank () == Rank::ace) {
        return true;
    }
    else {
        return false;
    }
}

int Black_Jack::get_card_value (Card card) {
    if (card.get_rank () <= Rank::ten) {
        return static_cast<int> (card.get_rank ());
    }
    else if (is_ace (card)) {
        return 11;
    }
    else {
        return 10;
    }
}

int Black_Jack::get_hand_score (std::vector<Card> hand) {
    int summ = 0;
    int count_ace = 0;

    for (int i = 0; i < hand.size (); i++) {
        if (is_ace (hand.at (i))) {
            count_ace++;
        }
        summ += get_card_value (hand.at (i));    
    }

    if (summ > 21 && count_ace > 0) {
        return summ - 10 * (count_ace - 1);
    }
    else {
        return summ;
    }
}

bool Black_Jack::ask_player_draw_card () {
    char answer;

    std::cout << "\nAnother Card? (y/n)\t";
    std::cin >> answer;

    if (tolower (answer) == 'y') {
        return true;
    }   
    else {
        return false;
    }
}

void Black_Jack::draw_player_card () {
    Card new_card = deck.draw_card ();
    player_hand.push_back (new_card);
    player_hand_sum = get_hand_score (player_hand);
}

void Black_Jack::draw_dealer_card () {
    Card new_card = deck.draw_card ();
    dealer_hand.push_back (new_card);
    dealer_hand_sum = get_hand_score (dealer_hand);
}

void Black_Jack::play_game () {

    bool player_winner = false;
    bool dealer_winner = false;

    deck.shuffle ();

    Black_Jack::draw_player_card ();
    Black_Jack::draw_dealer_card ();
    Black_Jack::draw_player_card ();
    Black_Jack::draw_dealer_card ();

    while (player_hand_sum < 21 || dealer_hand_sum < 21) {
        
        std::cout << "Player hand:" << '\n';
        for (int i = 0; i < player_hand.size (); i++) {
            Card card (player_hand.at (i));
            std::cout << card.to_string () << '\n';
        }

        std::cout << "Dealer hand:" << '\n';
        for (int i = 0; i < dealer_hand.size (); i++) {
            Card card (dealer_hand.at (i));
            if (i == 0) {
                std::cout << "x" << '\n';
            }
            else {
                std::cout << card.to_string () << '\n';
            }
        }

        bool extra_card = Black_Jack::ask_player_draw_card ();
        if (extra_card) {
            Black_Jack::draw_player_card ();
        }
        if (!extra_card) {
            while (dealer_hand_sum < 17) {
                draw_dealer_card ();
            }
            break;
        }   
    }


    if (player_hand_sum == 21) {
        std::cout << "Black Jack" << '\n'
        << "Winner Winner Chicken Dinner" << '\n';
        player_winner = true;
    }

    else if (player_hand_sum > dealer_hand_sum && player_hand_sum < 21) {
        std::cout << "Winner Winner Chicken Dinner" << '\n'
        << "You beat the Dealer!" << '\n';
        player_winner = true;
    }

    else if (player_hand_sum < 21 && dealer_hand_sum > 21) {
        std::cout << "Winner Winner Chicken Dinner" << '\n'
        << "Dealer is Bust!" << '\n';
        player_winner = true;
    }

    else {
        std::cout << "You Bust!" << '\n'
        << "Looser" << '\n';
        dealer_winner = true;
    }  
}