# include "card.h"
# include <iostream>
# include <unordered_map>


const std::unordered_map<Suit, std::string> suit_map {
    {Suit::clubs, "Clubs"},
    {Suit::diamonds, "Diamonds"},
    {Suit::hearts, "Hearts"},
    {Suit::spades, "Spades"},
};

const std::unordered_map<Rank, std::string> rank_map {
    {Rank::two, "Two"},
    {Rank::three, "Three"},
    {Rank::four, "Four"},
    {Rank::five, "Five"},
    {Rank::six, "Six"},
    {Rank::seven, "Seven"},
    {Rank::eight, "Eight"},
    {Rank::nine, "Nine"},
    {Rank::ten, "Ten"},
    {Rank::jack, "Jack"},
    {Rank::queen, "Queen"},
    {Rank::king, "King"},
    {Rank::ace, "Ace"},
};

// Oppgave 1c)
std::string suit_to_string (Suit suit) {
    return suit_map.at (suit);
}

// Oppgave 1d)
std::string rank_to_string (Rank rank) {
    return rank_map.at (rank);
}

// Oppgave 2b)
Card::Card (Suit suit, Rank rank) : s{suit}, r{rank}
{}

// Oppgave 2c)
Suit Card::get_suit () {
    return s;
}

// Oppgave 2d)
Rank Card::get_rank () {
    return r;
}

// Oppgave 2e)
std::string Card::to_string () {
    return rank_to_string (r) + " of " + suit_to_string (s);
}

