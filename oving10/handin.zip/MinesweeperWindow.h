# pragma once
# include "AnimationWindow.h"
# include "widgets/TextInput.h"
# include "Tile.h"
# include "random"
# include <iostream>
# include <chrono>

using namespace std;
using namespace TDT4102;

// Minesweeper GUI
class Minesweeper_Window : public AnimationWindow
{
public:
	// storrelsen til hver tile
	static constexpr int cell_size = 30;
	Minesweeper_Window (int x, int y, int width, int height, int mines, const string& title);
private:
	const int width;		// Bredde i antall tiles
	const int height;		// Hoyde i antall tiles
	const int tot_mines;	// Antall miner
	const Point win_point;	// punkt for vinduets plassering
	int num_mines;			// Redusernede antall miner ettersom man flagger
	bool winner = false;
	bool looser = false;
	TDT4102::TextInput text_num_mines;		// viser hvor mange miner som ikke er flagget
	TDT4102::TextInput text_check_winner; 	// skjekker om spiller har vunnet eller ikke og skriver det til skjerm
	//Tile button_reset;					// resetter spillet

	vector<shared_ptr<Tile>> tiles; 		// Vektor som inneholder alle tiles

	// hoyde og bredde i piksler
	int Height() const { return height * cell_size; } 
	int Width() const { return width * cell_size; }

	// Returnerer en vektor med nabotilene rundt en tile, der hver tile representeres som et punkt
	vector<Point> adjacent_points(Point xy) const;

	// tell miner basert paa en liste tiles
	int count_mines(vector<Point> coords) const;

	// Sjekker at et punkt er paa brettet
	bool in_range(Point xy) const { return xy.x >= 0 && xy.x< Width() && xy.y >= 0 && xy.y < Height(); }

	// Returnerer en tile gitt et punkt
	shared_ptr<Tile>& at(Point xy) { return tiles [xy.x / cell_size + (xy.y / cell_size) * width]; }
	const shared_ptr<Tile>& at(Point xy) const { return tiles [xy.x / cell_size + (xy.y / cell_size) * width]; }

    //aapne og flagge rute
	void open_tile(Point xy);
	void flag_tile(Point xy);

	// callback funksjoner til Tile knappene
	void cb_click();

	// gir random plassering av miner innenfor vektorstørrelsen
	int random_with_limits (int lower, int upper);
	void place_mines ();

	// teller hvor mange miner det er i nærheten.
	int count_mines (std::vector<Point> points);

	// åpner alle miner dersom spilleren taper
	void check_looser ();

	void check_winner ();

};
