#include "MinesweeperWindow.h"


Minesweeper_Window::Minesweeper_Window (int x, int y, int width, int height, int mines, const string &title) : 
	// Initialiser medlemsvariabler, bruker konstruktoren til AnimationWindow-klassen
	AnimationWindow {x, y, width * cell_size, (height + 2) * cell_size, title},
	width {width}, 
	win_point {x, y},
	height {height}, 
	tot_mines {mines},
	num_mines {mines},
	text_num_mines {{width * cell_size - cell_size * 4, height * cell_size}, cell_size * 4, cell_size, "Mines: " + to_string (mines)},
	text_check_winner {{0, height * cell_size}, cell_size * 7, cell_size, "You have not lost yet."}
	//button_reset {{width * cell_size / 2, height * cell_size}, cell_size * 1.5, cell_size, ";-)"}
{
	// Legg til alle tiles i vinduet
	for (int i = 0; i < height; ++i) {
		for (int j = 0; j < width; ++j) {
			tiles.emplace_back (new Tile { Point{j * cell_size, i * cell_size}, cell_size});
			tiles.back () -> setCallback (std::bind (&Minesweeper_Window::cb_click, this));
			auto temp = tiles.back ().get ();
			add (*temp); 
		}
	}
	place_mines ();

	// viser hvor mange miner som ikke er flagget på skjerm.
	add (text_num_mines);
	add (text_check_winner);
	

}

vector<Point> Minesweeper_Window::adjacent_points (Point xy) const {
	vector<Point> points;
	for (int di = -1; di <= 1; ++di) {
		for (int dj = -1; dj <= 1; ++dj) {
			if (di == 0 && dj == 0) {
				continue;
			}
			Point neighbour { xy.x + di * cell_size,xy.y + dj * cell_size };
			if (in_range (neighbour)) {
				points.push_back (neighbour);
			}
		}
	}
	return points;
}

void Minesweeper_Window::open_tile (Point xy) {
	shared_ptr<Tile> T = at (xy);
	if (T -> get_state () != Cell::closed) { return; }

	T -> open (); 
	vector<Point> adj_point = adjacent_points (xy);

	if (!T -> get_is_mine ()) {
		int n_mines = count_mines (adj_point);
		if (n_mines > 0) 
			{ T -> set_adj_tiles (n_mines); }
		else if (n_mines == 0) {
			for (Point t : adj_point) {	open_tile (t); } 
		}
		// skjekker om man vinner eller taper hver gang et felt blir åpnet
		check_winner ();
	}
	else {
		check_looser ();
	}
}

void Minesweeper_Window::flag_tile (Point xy) {
	shared_ptr<Tile> T = at (xy);
	T -> flag ();

	if (T -> get_state () == Cell::flagged) { num_mines --; }
	else { num_mines ++; }

	if (num_mines == 0 ) { check_winner (); }
	text_num_mines.setText ("Mines: " + to_string (num_mines));
}

//Kaller openTile ved venstreklikk og flagTile ved hoyreklikk
void Minesweeper_Window::cb_click () {
	if (! (looser || winner)) {
		Point xy {this -> get_mouse_coordinates ()};
		//std::cout << xy.x << " " << xy.y <<": " << xy.x / (cellSize) + (xy.y / cellSize) * width<<"\n";

		if (!in_range (xy)) { return; }
		if (this -> is_left_mouse_button_down ()) {	open_tile (xy);	}
		else if (this -> is_right_mouse_button_down ()) { flag_tile (xy); }
	}
}

int Minesweeper_Window::random_with_limits (int lower, int upper) {
	std::uniform_int_distribution<int> distribution (lower, upper);
    std::random_device random;
    std:: default_random_engine generator (random ());
    return distribution (generator);
}

void Minesweeper_Window::place_mines () {
	int count_mines = 0;
	while (count_mines < tot_mines) {
		int random_num = Minesweeper_Window::random_with_limits (0, tiles.size ());

		if (tiles.at (random_num).get () -> get_is_mine () == true) { continue; }
		else {
			tiles.at (random_num).get () -> set_is_mine (true);
			count_mines++;
		}
	}
}

int Minesweeper_Window::count_mines (std::vector<Point> points) {
	int count_mines = 0;
	for (Point p : points) {
		shared_ptr<Tile> T = at (p);
		if (T -> get_is_mine ()) { count_mines ++; }
	}
	return count_mines;
}

void Minesweeper_Window::check_looser () {
	looser = true;
	text_check_winner.setText ("Big looser!!");
	for (shared_ptr<Tile> T : tiles) {
		if (T -> get_is_mine ()) {
			T -> open ();
		}	
	}
}

void Minesweeper_Window::check_winner () {
	int count_unopend_tiles = 0;
	for (shared_ptr<Tile> T : tiles) {
		if (T -> get_state () != Cell::open) {
			count_unopend_tiles ++;
		}
	}
	if (count_unopend_tiles == tot_mines) {
		winner = true;
		text_check_winner.setText ("Congratualtions!!"); }
}
