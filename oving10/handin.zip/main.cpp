#include "MinesweeperWindow.h"





int main()
{

	// antall rader, koller og antall miner
	constexpr int width = 30;
	constexpr int height = 15;
	constexpr int mines = 100;

	constexpr Point start_point {100, 100};
	Minesweeper_Window mw{start_point.x, start_point.y, width, height, mines, "Minesweeper" };
	
	mw.wait_for_close();




	return 0;
}