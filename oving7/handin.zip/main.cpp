# include "oppgave1.h"
# include <iostream>

// Oppgave 1a)
    // Forskjellen på public, private og protected.
    // Pulic er medlemsfunksjoner som funksjoner utenfor klassen har tilgang til.
    // Private er medlemsfunksjoner som kun er tilgjengelig innad i klassen.
    // protected er funksjoner og variable som ikke er tilgjengelig uettnfor klassen, men er tilgjengelig for andre klasser som arver klassen.

/*
int main () {
    // oppgave 1d)
    // Animal a {"Horse", 20};

   
    std::cout << a.to_string () << std::endl;;
    
    std::vector<std::unique_ptr<Animal>> dyr;
    dyr.emplace_back (new Animal ("Kollibri", 1));
    dyr.emplace_back (new Animal ("Kanarifugl", 2));
    dyr.emplace_back (new Animal ("Dompap", 3));

    for (int i = 0; i < dyr.size (); i++) {
        std::cout << dyr.at (i) -> to_string () << std::endl;
    }
    


    
    return 0;
}
*/