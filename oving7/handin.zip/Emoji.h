# pragma once
# include "std_lib_facilities.h"
# include "AnimationWindow.h"

// Abstrakt klasse. Arvende konkrete klasser må implementere funksjonen draw()
// som tegner former i vinduet de skal bli vist i.
class Emoji {
public:
    virtual void draw (AnimationWindow& window) = 0;
    virtual ~Emoji () {}; //destruktør
};

class Face : public Emoji {
    protected:
        Point center;
        int radius;
    public:
        virtual void draw (AnimationWindow& window) override = 0;
        Face (Point c, int r) : 
            center {c}, 
            radius {r}
        {};
};

class Empty_Face : public Face {
    protected:
        Point right_eye;
        Point left_eye;
        int rad;
    public:
        void draw (AnimationWindow& window) override;
        void draw_left_eye (AnimationWindow &window);
        Empty_Face (Point c, int r) : 
            Face {c, r}, 
            right_eye {center.x + static_cast<int> (radius * 0.33), center.y - static_cast<int> (radius * 0.2)}, 
            left_eye {center.x - static_cast<int> (radius * 0.33), center.y - static_cast<int> (radius * 0.2)}, 
            rad {static_cast<int> (radius * 0.25)}
        {};
};

class Smiley_Face : public Empty_Face {
    protected:
        int width;
        int height;
        int start_degree;
        int end_degree;
    public:
        void draw (AnimationWindow &window) override;
        void draw_smile (AnimationWindow &window);
        Smiley_Face (Point c, int r) :
            Empty_Face {c, r},
            width {static_cast<int> (Face::radius * 0.75)},
            height {static_cast<int> (Face::radius * 0.5)},
            start_degree {180},
            end_degree {360}
        {};
};

// velger å opprette en ny klasse fordi surt ansikt har flyttet senter for buen. 
// Denne senter varabelen er definert i Face, og dersom amn endrer på den vil øynene også flyttes.
class Sad_Face : public Empty_Face {
    protected:
        Point center_smile;
        int width;
        int height;
        int start_degree;
        int end_degree;
    public:
        void draw (AnimationWindow &window) override;

        Sad_Face (Point c, int r) :
            Empty_Face {c, r},
            center_smile {Face::center.x, Face::center.y + static_cast<int> (Face::radius * 0.5)},
            width {static_cast<int> (Face::radius * 0.75)},
            height {static_cast<int> (Face::radius * 0.5)},
            start_degree {0},
            end_degree {180}
        {};
};

class Angry_Face : public Sad_Face {
    protected:
        Point center_right_brow;
        Point center_left_brow;
        int width;
        int height;
        int start_degree_right_borw;
        int end_degree_right_brow;
        int start_degree_left_brow;
        int end_degree_left_brow;
    public:
        void draw (AnimationWindow &window) override;
        Angry_Face (Point c, int r) :
            Sad_Face {c, r},
            center_left_brow {Empty_Face::left_eye.x, Empty_Face::left_eye.y - static_cast<int> (Face::radius * 0.35)},
            center_right_brow{Empty_Face::right_eye.x, Empty_Face::right_eye.y - static_cast<int> (Face::radius * 0.35)},
            width {static_cast<int> (Face::radius * 0.25)},
            height {static_cast<int> (Face::radius * 0.2)},
            start_degree_left_brow {0},
            end_degree_left_brow {120},
            start_degree_right_borw {30},
            end_degree_right_brow {180}
        {};
};

class Winky_Face : public Smiley_Face {
    protected:
        Point start;
        Point end_lower;
        Point end_upper;
        
    public:
        void draw (AnimationWindow &window) override;
        Winky_Face (Point c, int r) :
            Smiley_Face {c, r},
            start {Face::center.x + static_cast<int> (Face::radius * 0.2), Face::center.y - static_cast<int> (Face::radius * 0.2)},
            end_lower {Face::center.x + static_cast<int> (Face::radius * 0.4), Face::center.y - static_cast<int> (Face::radius * 0.1)},
            end_upper {Face::center.x + static_cast<int> (Face::radius * 0.4), Face::center.y - static_cast<int> (Face::radius * 0.3)}
        {};
};

class Wow_Face : public Empty_Face {
    protected:
        Point center_smile;
        int rad;
    public:
        void draw (AnimationWindow &window) override;
        Wow_Face (Point c, int r) :
            Empty_Face {c, r},
            center_smile {c.x, c.y + static_cast<int> (r * 0.3)},
            rad {static_cast<int> (r * 0.3)}
        {};
};