# pragma once
# include <string>
# include <vector>
# include "std_lib_facilities.h"

class Animal {
protected:
    std::string name;
    int age;
public:
    Animal (std::string n, int a) : name{n}, age{a} {};
    Animal () {
        name = "Navn Navnesen";
        age = 0;
    };
    virtual ~Animal () {};
    virtual std::string to_string () const = 0;
};

class Cat : public Animal {
public:
    Cat (std::string n, int a) : Animal {n, a} {};
    std::string to_string () const override;
};

class Dog : public Animal {
public:
    Dog (std::string n, int a) : Animal {n, a} {};
    std::string to_string () const override;
};

// oppgave 1d)
