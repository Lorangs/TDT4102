# include "oppgave1.h"

std::string Animal::to_string () const {
    return "Animal: " + name + "\n" + "Age: " + std::to_string (age);
}

std::string Cat::to_string () const {
    return "Cat: " + name + "\n" + "Age: " + std::to_string (age);
}

std::string Dog::to_string () const {
    return "Dog: " + name + "\n" + "Age: " + std::to_string (age);
}

