#include "AnimationWindow.h"
#include "Emoji.h"


// Definer størrelse på vindu og emoji
constexpr int x_max = 1000.0;
constexpr int y_max = 600.0;
constexpr Point center_screen {x_max / 2, y_max / 2};
constexpr int emoji_radius = 50;

constexpr Point tl {100, 100};
const string win_label {"Emoji factory"};

int main() {

	AnimationWindow win {tl.x, tl.y, x_max, y_max, win_label};
	Winky_Face a (center_screen, emoji_radius);
	a.draw (win);

	win.wait_for_close ();

	return 0;
}


