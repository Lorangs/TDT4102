#include "Emoji.h"

void Face::draw (AnimationWindow &window) {
    window.draw_circle (center, radius, Color::yellow, Color::black);
}

void Empty_Face::draw (AnimationWindow &window) {
    Face::draw (window);
    window.draw_circle (right_eye, rad, Color::brown, Color::black);
    window.draw_circle (left_eye, rad, Color::brown, Color::black);
}

void Empty_Face::draw_left_eye (AnimationWindow &window) {
    window.draw_circle (left_eye, rad, Color::brown, Color::black);
}

void Smiley_Face::draw (AnimationWindow &window) {
    Empty_Face::draw (window);
    window.draw_arc (Face::center, width, height, start_degree, end_degree, Color::black);
}

void Smiley_Face::draw_smile (AnimationWindow &window) {
    window.draw_arc (Face::center, width, height, start_degree, end_degree, Color::black);
}

void Sad_Face::draw (AnimationWindow &window) {
    Empty_Face::draw (window);
    window.draw_arc (center_smile, width, height, start_degree, end_degree, Color::black);
}

void Angry_Face::draw (AnimationWindow &window) {
    Sad_Face::draw (window);
    window.draw_arc (center_left_brow, width, height, start_degree_left_brow, end_degree_left_brow);
    window.draw_arc (center_right_brow, width, height, start_degree_right_borw, end_degree_right_brow);
}

void Winky_Face::draw (AnimationWindow &window) {
    Face::draw (window);
    Smiley_Face::draw_smile (window);
    Empty_Face::draw_left_eye (window);
    window.draw_line (start, end_lower, Color::black);
    window.draw_line (start, end_upper, Color::black);
}

void Wow_Face::draw (AnimationWindow &window) {
    Empty_Face::draw (window);
    window.draw_circle (center_smile, rad, Color::brown, Color::black);
}