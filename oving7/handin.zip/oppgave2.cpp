# include "oppgave2.h"
