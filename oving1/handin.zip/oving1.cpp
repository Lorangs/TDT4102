#include "std_lib_facilities.h"

int maxOfTwo (int a, int b) {
    if (a > b) {
        cout << "A is greater than B" << endl;
        return a;
    }
    else {
        cout << "B is greater than A" << endl;
        return b;
    }
}

int fibonacci (int n) {
    int a = 0;
    int b = 1;
    cout << "Fibonacci Numbers: " << endl;
    for (int i = 0; i < n + 1; ++i) {
        cout << i << " " << b << endl;
        int temp = b;
        b += a;
        a = temp;
    }
    cout << "----" << endl;
    return b;
}

int squareNumberSum (int n) {
    cout << "Square numbers sum in " << n << " steps" << endl;
    int totalSum = 0;
    for (int i = 1; i < n + 1; ++i){
        totalSum += i * i;
        cout << i * i << endl;
    }
    cout << totalSum << endl;
    return totalSum;
}

void triangleNumbersBelow (int n) {
    int acc = 1;
    int num = 2;
    cout << "Triangle Numbers below " << n << ":" << endl;
    while (acc < n) {
        cout << acc << endl;
        acc += num;
        num += 1;
    }
}

bool isPrime (int n) {
    for (int i = 2; i < n; ++i) {
        if (n % i == 0) {
            return false;
        }
    }
    return true;
}

void naivePrimeNumberSearch (int n) {
    for (int i = 2; i < n; ++i) {
        if (isPrime(i)) {
            cout << i << " is a prime" << endl;
        }
    }
}

int findGreatestDivisor (int n) {
    for (int i = n - 1; i > 0; --i) {
        if (n % i == 0) {
            return i;
        }
    
    }
}


int main () {
    cout << "Oppgave a) " << endl;
    cout << maxOfTwo(5, 6) << endl;
    cout << '\n';

    cout << "Oppgave c) " << endl;
    cout << fibonacci(5) << endl;
    cout << '\n';

    cout << "Oppgave d) " << endl;
    cout << squareNumberSum(5) << endl;
    cout << '\n';

    cout << "Oppgave e) " << endl;
    triangleNumbersBelow(5); 
    cout << '\n';

    cout << "Oppgave f) " << endl;
    cout << isPrime(5) << endl;
    cout << '\n';

    cout << "Oppgave g) " << endl;
    naivePrimeNumberSearch(10);
    cout << '\n';

    cout << "Oppgave h) " << endl;
    cout << findGreatestDivisor(10) << endl;

    return 0;
}