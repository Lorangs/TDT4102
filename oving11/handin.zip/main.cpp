# include "oppgave1.h"
# include "oppgave2.h"



std::vector<std::string> vektor {"Hei", "mitt", "navn", "er", "Lorang"};

int main () {
    // oppgave1a)
    for (std::vector<std::string>::iterator p = vektor.begin (); p != vektor.end (); p++) {
        std::cout << *p << " " << std::endl;
    }
    
    // oppgave 1b)
    for (std::vector<std::string>::reverse_iterator p = vektor.rbegin (); p != vektor.rend (); p++)
        std::cout << *p << " " << std::endl;
    
    
    // oppgave 2b)
    Person a {"Strand", "Lorang"};
    Person b {"Pedersen", "Arne"};
    Person c {"Arnesen", "Åge"};

    std::list<Person> navneliste;
    insert_ordered (navneliste, b);
    insert_ordered (navneliste, a);
    insert_ordered (navneliste, c);

    for (Person p : navneliste) {
        std::cout << p << std::endl;
    }

    return 0;
}