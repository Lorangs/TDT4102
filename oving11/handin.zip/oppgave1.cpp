# include "oppgave1.h"

void replace_1 (std::vector<std::string> &vec, std::string old, std::string replacement) {
    for (std::vector<std::string>::iterator i = vec.begin (); i != vec.end (); i++) {
        if (*i == old) {
            vec.erase (i);
            vec.insert (i, replacement);
        }
    }
}

void replace_2 (std::set<std::string> &sett, std::string old, std::string replacement) {
    for (std::set<std::string>::iterator i = sett.begin (); i != sett.end (); i++) {
        if (*i == old) {
            sett.erase (i);
            sett.insert (i, replacement);
        }
    }
}