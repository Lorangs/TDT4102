# pragma once
# include <vector>
# include <iostream>
# include <set>


void replace_1 (std::vector<std::string> &vec, std::string old, std::string replacement);
void replace_2 (std::set<std::string> &sett, std::string old, std::string replacement);