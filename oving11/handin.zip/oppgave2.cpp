# include "oppgave2.h"

std::ostream &operator<< (std::ostream &os, const Person &P) {
    return os << P.sur_name << ", " << P.first_name;
}

void insert_ordered (std::list<Person> &l, const Person &p) {
    // legger inn en skjekk som kontrollere at personen har blitt lagt til lista.
    bool check_insertion = false;

    // hvis lista ikke har noen elementer legges den til som første
    if (l.size () == 0) {
        l.push_back (p);
        check_insertion = true;
    }
    else {
        // iterer gjennom lista og finner hvor navnene ikke lenger er mindre lik nye navnet og legger denne til her.
        for (std::list<Person>::iterator i = l.begin (); i != l.end (); i++) {

            // henter ut etternavnet og sorterer ut fra det.
            if (i -> get_sur_name () <= p.get_sur_name ()) {
                continue;
            }
            else {
                l.insert (i, p);
                check_insertion = true;
                break;
            } 
        }
    }
    // hvis navnet er større enn alle elementene i lista vil den likevelbli lagt til bakerst
    if (!check_insertion) {
        l.push_back (p);
    }
}