# include "linked_list.h"


namespace LinkedList{
std::ostream &operator<< (std::ostream &os, const Node & node) {
return os << node.getValue ();
}

Node* LinkedList::insert (Node* pos, const std::string & value) {
    assert (pos != nullptr);
    if (pos == begin ()) {
        head = std::make_unique<Node> (value, std::move (head), nullptr);
        pos -> prev = begin ();
    }
    else {
        Node* prev_node = pos -> prev;
        prev_node -> next = std::make_unique<Node> (value, std::move (prev_node -> next), prev_node);
        pos -> prev = prev_node -> getNext ();
    }
    return pos -> prev;     
}

Node* LinkedList::remove (Node* pos) {
    assert (pos != nullptr);
    if (pos = begin ()){
        // flytter pekeren fra denne noden til neste
        head = std::move (pos -> next);
        // pekeren til forrige element blir satt til nullptr da den er det førtse elementet 
        head -> prev = nullptr;
        // returnerer pekeren til andre element, som nå blir første ettersom vi fjerner den første
        return begin ();
    }
    else {
        Node* ptr_next_elem = pos -> getNext ();
        // flytter neste node "prev" til å bli forrige nodes
        ptr_next_elem -> prev = pos -> getPrev ();
        // flytter eierskap av "next" unique_ptr til forrige node.
        pos -> prev-> next = std::move (pos -> next); 
        return ptr_next_elem;
    }   
}

Node* LinkedList::find (const std::string & val) {
    Node* node = begin ();
    while (node != end () && node -> value != val) {
        node = node -> getNext ();
    }
    return node;
}

void LinkedList::remove (const std::string & val) {
    Node* node = find (val);
    if (node != end()) {
        remove (node);
    }
}

std::ostream &operator<< (std::ostream &os, const LinkedList & list){
    Node* iterator = list.begin ();
    os << "[ ";
    while (iterator != list.end ()) {
        os << iterator -> getValue () + " ";
        iterator = iterator -> getNext ();
    }
    os << " ]";
    return os;
}

} // namespace linkedList

