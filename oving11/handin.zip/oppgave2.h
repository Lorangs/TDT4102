# pragma once
# include <string>
# include <iostream>
# include <list>

class Person {
    private:
        std::string sur_name;
        std::string first_name;
        
    public:
        Person () : sur_name {"Navnesen"}, first_name {"Navn"} {};
        Person (std::string s_name, std::string f_name) : sur_name {s_name}, first_name {f_name} {};

        std::string get_name () { return sur_name + ", " + first_name; };
        std::string get_first_name () const { return first_name; };
        std::string get_sur_name () const { return sur_name; } ;
        void set_name (std::string &f_name, std::string &s_name) { sur_name = s_name; first_name = f_name; };
        void set_first_name (std::string &f_name) { first_name = f_name; };
        void set_sur_name (std::string &s_name) { sur_name = s_name; };
    
    friend std::ostream &operator<< (std::ostream &os, const Person &P);
};

void insert_ordered (std::list<Person> &l, const Person &p);