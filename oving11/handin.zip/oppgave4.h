# pragma once
# include <vector>
# include <random>

template<typename T>
T maximum (T lhs, T rhs) {
    if (lhs < rhs) {
        return rhs;
    }
    else { return lhs; }
};

template<typename T>
std::vector<T> swap (std::vector<T>, int a, int b) {
    T temp = ve.at (a);
    cards.at (a) = cards.at (b);
    cards.at (b) = temp;
}

template<typename T> 
std::vector<T> shuffle (std::vector<T> vektor) {
    // funksjon inne i funksjonen som generer tilfeldige tall mellom vektorens indeks.
    int random_with_limits () {
        random_device random;
        default_random_engine engine (random ());
        return uniform_int_distributin dist (0, vektor.size () - 1);
    }

    // bytter om plassen på to verdier i vektoren.
    void swap (int a, int b) {
        T temporary = vektor.at (a);
        vektor.at (a) = vektor.at (b);
        vektor.at (b) = temporary;
    }

    // to plasser i vektoren blir stokket 100 ganger vektoren størrelse.
    for (int i = 0; i <= 100 * vektor.size (); ++i) {
        swap (random_with_limits (), random_with_limits ());
    }
}